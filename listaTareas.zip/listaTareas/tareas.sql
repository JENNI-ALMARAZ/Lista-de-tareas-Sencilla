/*
 Navicat Premium Data Transfer

 Source Server         : ing_software
 Source Server Type    : MariaDB
 Source Server Version : 100616 (10.6.16-MariaDB-0ubuntu0.22.04.1)
 Source Host           : localhost:3306
 Source Schema         : tareas

 Target Server Type    : MariaDB
 Target Server Version : 100616 (10.6.16-MariaDB-0ubuntu0.22.04.1)
 File Encoding         : 65001

 Date: 24/11/2023 09:48:14
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tareas
-- ----------------------------
DROP TABLE IF EXISTS `tareas`;
CREATE TABLE `tareas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tarea` text NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Records of tareas
-- ----------------------------
BEGIN;
INSERT INTO `tareas` (`id`, `tarea`, `fecha`, `hora`) VALUES (8, 'Holaa\r\n', '2023-11-23', '09:53:27');
INSERT INTO `tareas` (`id`, `tarea`, `fecha`, `hora`) VALUES (11, 'Lavar ropa', '2023-11-23', '09:59:54');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
