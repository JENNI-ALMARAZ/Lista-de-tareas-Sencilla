<?php

$DB_HOST = "localhost";
$DB_USER = "root";
$DB_PASS = "je13nni14";
$DB_DB = "tareas";

$conn = mysqli_connect($DB_HOST,$DB_USER,$DB_PASS,$DB_DB);

?>